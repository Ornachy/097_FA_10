# Flutter Login App

This is a simple **Login & Sign Up App** built with Flutter.  
It demonstrates the use of **Stack, Image, Positioned, Expanded, Container, and Navigator**.

## 🚀 Features
- Beautiful background image with overlay form
- Sign In page with Email & Password fields
- Sign Up page with Email, Password & Confirm Password fields
- Navigation between Sign In & Sign Up pages
- Responsive design using **Expanded** and **Container**

## 📂 Project Structure
```
lib/
 ├── main.dart         # Entry point of the app
 ├── signin_page.dart  # Sign In page UI
 └── signup_page.dart  # Sign Up page UI
assets/
 └── images/
     └── bg_image1.png # Background image
```

## 🛠️ Setup & Run
1. Clone the repository or extract the provided zip file.
2. Open the project in **Visual Studio Code** or Android Studio.
3. Run the following commands:
   ```bash
   flutter pub get
   flutter run
   ```
4. The app will launch with the **Sign In Page**.  
   - Tap **Sign Up** → Navigate to Sign Up page  
   - Tap **Sign In** → Navigate back

## 📌 Requirements
- Flutter SDK installed ([Install Guide](https://docs.flutter.dev/get-started/install))
- Android/iOS Emulator or a physical device

---
✅ You can now push this project to GitHub (repository name format: `ID_FA_9` as per assignment).
